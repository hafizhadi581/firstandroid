package com.example.asdscreening;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Fifthteenth_Question extends AppCompatActivity {

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifthteenth_question);
    }
}
